#!/bin/bash

awk 'BEGIN {print "Female total:" }'
awk '/$7!= "Male|Female/' formatdata.csv |less -S | wc -l

awk 'BEGIN { print "Male total:"}'
awk '/$7!= "Female|Male/' formatdata.csv |less -S | wc -l

awk '/$7!= "Male|Female/{ total += $6; count++} 
END {print "Average Female age:"total/count }' formatdata.csv

awk '/$7!= "Female|Male/{ total += $6; count++ } 
END {print "Average Male age: " total/count }' formatdata.csv

awk 'BEGIN { print "White Female Total: "}'
awk '{ if(($8=="White" && $7 =="Female") ) print }' formatdata.csv | less -S | wc -l

awk 'BEGIN { print "Black Female Total: "}'
awk '{ if(($8=="Black" && $7 =="Female") ) print }' formatdata.csv | less -S | wc -l

awk 'BEGIN { print "Black Male Total: "}'
awk '{ if(($8=="Black" && $7 =="Male") ) print }' formatdata.csv | less -S | wc -l

awk 'BEGIN { print "White Male Total: "}'
awk '{ if(($8=="White" && $7 =="Male") ) print }' formatdata.csv | less -S | wc -l



awk 'BEGIN { print "White Female average Age:"}'
awk '{ total += $1; counter++ } END {print total/counter }' WhiteFemales.txt

awk 'BEGIN { print "White Male average Age:"}'
awk '{ total += $1; counter++ } END {print total/counter }' WhiteMales.txt

awk 'BEGIN { print "Black Female average Age:"}'
awk '{ total += $1; counter++ } END {print total/counter }' BlackFemales.txt

awk 'BEGIN { print "Black male average Age:"}'
awk '{ total += $1; counter++ } END {print total/counter }' BlackMales.txt




awk 'BEGIN {print "White Female min Age:" }'
awk 'BEGIN{holder=1000}{if ($1<0+holder) holder=$1} END{print holder}' WhiteFemales.txt

awk 'BEGIN {print "White Female max Age:" }'
awk 'BEGIN{holder=0}{if ($1>0+holder) holder=$1} END{print holder}' WhiteFemales.txt

awk 'BEGIN {print "Black Female min Age:" }'
awk 'BEGIN{holder=1000}{if ($1<0+holder) holder=$1} END{print holder}' BlackFemales.txt

awk 'BEGIN {print "Black Female max Age:" }'
awk 'BEGIN{holder=0}{if ($1>0+holder) holder=$1} END{print holder}' BlackFemales.txt

awk 'BEGIN {print "Black Male min Age:" }'
awk 'BEGIN{holder=1000}{if ($1<0+holder) holder=$1} END{print holder}' BlackMales.txt

awk 'BEGIN {print "Black Male max Age:" }'
awk 'BEGIN{holder=0}{if ($1>0+holder) holder=$1} END{print holder}' BlackMales.txt

awk 'BEGIN {print "White Male min Age:" }'
awk 'BEGIN{holder=1000}{if ($1<0+holder) holder=$1} END{print holder}' WhiteMales.txt

awk 'BEGIN {print "White Male max Age:" }'
awk 'BEGIN{holder=0}{if ($1>0+holder) holder=$1} END{print holder}' WhiteMales.txt

